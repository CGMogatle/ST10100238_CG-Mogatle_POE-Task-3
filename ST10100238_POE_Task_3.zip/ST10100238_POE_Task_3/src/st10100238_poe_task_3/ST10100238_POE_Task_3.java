
package st10100238_poe_task_3;
import java.util.Scanner;
import javax.swing.*;

/**
 *
 * @author Calista
 */
public class ST10100238_POE_Task_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

            public static Scanner input = new Scanner(System.in);  
            public static Tasks = new Tasks();
            public static void main(String[] args){
    //main class acting as a caller method
    JOptionPane.showMessageDialog(null,"***********************\nWELCOME TO EASYKANBAN\n*************************");
    Task.prompt();
  }    
 }

}

package st10100238_poe_task_3;
    import java.util.Scanner;
    import javax.swing.JOptionPane;
/**
 *
 * @author Calista
 */
public class Tasks {
    
    //variable declarations of array
    public int SIZE = 1;
    public int NumOfTasks = 0;
    private String TaskID[] = new String[SIZE];
    private String Name[] = new String[SIZE];
    private String Category1[] = new String[SIZE];
    private String Duration[] = new String[SIZE];
    private String DEVELOPER[] = new String[SIZE];
    private double PRICETAG[] = new double[SIZE];
    private int Task_Levels1[] =  new int[SIZE];
    
   
    private static final Scanner input = new Scanner(System.in);   
    public static String TaskID;
    public static String Category;
    public static String Warranty;
    public static String Developer;
    public static double Price;
    public static int Task_Levels;
    public static String Code;
    public static Tasks = new Tasks();
    public Tasks(){
    } 
    // capturing data
    public void SaveTask( 
            String UniqueID,
            String TaskName, 
            String TaskCategory, 
            String TaskDuration, 
            String TaskDeveloper, 
            double TaskPrice, 
            int TaskLevel);
    //adding a task to array
    {
        if(NumOfTasks== SIZE)
        {reSize();}
        System.out.println("NUMBER OF TASKS PRIOR:" + NumOfTasks);
        TaskID[NumOfTasks]n = UniqueID;
        Name[NumOfTasks] = TaskNamee;
        Category1[NumOfTasks] = TaskCategory;
        Duration[NumOfTasks] = TaskDuration;
        Develop[NumOfTasks] = TaskDeveloper;
        Pricetag[NumOfTasks] = TaskPrice;
        Task_levels[NumOfTasks] = TaskLevel;
        NumOfTasks++;
        System.out.println("NUMBER OF TASKS AFTER:" + NumOfTasks);
    }
        public void reSize()
        //resize arrays to store more items
        {
        //code array
        String[] ptr = new String[SIZE+1];
        System.arraycopy(taskID, 0, ptr, 0, SIZE);
        for(int  k=0 ; k< SIZE; k++){TaskID[k] = null;}SIZE = SIZE +1; TaskID = ptr;

        //name array
        ptr = new String[SIZE];
        System.arraycopy(Name, 0, ptr, 0, SIZE-1);
        for(int  k=0 ; k< SIZE-1; k++){ Name[k] = null;} Name = ptr;

        
        //category array
        ptr = new String[SIZE];
        System.arraycopy(Category, 0, ptr, 0, SIZE-1);
        for(int  k=0 ; k< SIZE-1; k++){Category[k] = null;}Category = ptr;

        //warranty array
        ptr = new String[SIZE];
        System.arraycopy(Duration, 0, ptr, 0, SIZE-1);
        for(int  k=0 ; k< SIZE-1; k++){Duration[k] = null;}Duration = ptr;

        //supplier array
        ptr = new String[SIZE];
        System.arraycopy(Developer, 0, ptr, 0, SIZE-1);
        for(int  k=0 ; k< SIZE-1; k++){Developer[k] = null;}Developer = ptr;
        
        //price array
        double[]  ptr1 = new double[SIZE];
        System.arraycopy(Pricetag, 0, ptr1, 0, SIZE-1);Pricetag = new double[SIZE];Pricetag = ptr1; 

        //stock_levels array
        int ptr2[] = new int[SIZE];
        System.arraycopy(Task_levels1, 0, ptr2, 0, SIZE-1);
        Task_levels =  new int[SIZE];Task_levels1 = ptr2;
    }

    public int getTaskID(String c) {
        if (NumOfTasks == 0)
        {return Integer.MAX_VALUE;
        }for(int k=0; k<SIZE; k++)
        {if(TaskID[k].equals(c)){return k;}
        }return Integer.MAX_VALUE;}

    
    //GETTERS AND SETTERS
    public String getCode(int Calista)
    {
        return TaskID[Calista];
    }
    public void setCode(String code,int Calista) {
        this.TaskID[Calista] = code;}

    public String getName(int Calista) {
    return Name[Calista];}

    public void setName(String name, int Calista) {
        this.Name[Calista] = name;}

    public String getCategory(int Calista) {
        return Category[Calista];}

    public void setCategory(String category,int Calista) {
        this.Category[Calista] = category;}

    public String getWarranty(int Calista) {
        return Duration[Calista];}

    public void setWarranty(String warranty,int Calista) {
        this.Duration[Calista] = warranty;}

    public String getdeveloper(int Calista) {
        return Developer[Calista];}

    public void setSupplier(String supplier,int Calista) {
        this.Developer[Calista] = supplier;}

    public double getPrice(int Calista) {
        return Pricetag[Calista];}

    public void setPrice(double price,int Calista) {
        this.Pricetag[Calista] = price;}

    public int getStock_levels(int Calista){
        return Task_levels1[Calista];}

    public void setTask_levels(int task_levels,int Calista) {
        this.Task_levels1[Calista] = Task_levels;}
    
    public void prompt()
    //Asks the user if he/she wants to continue or not
    {
        String launchMenuOrTerminateProgram;
        System.out.print(
        "(1) LAUNCH AND LOGIN"
        + "\n(2) EXIT APPLICATION\n ");
        launchMenuOrTerminateProgram = input.nextLine();
        programIn(launchMenuOrTerminateProgram);
    }
    
    public void programIn(String c){//is used by prompt
        String menuChoice;
        if(c.equals("1"))
        {DisplayMenu();
        menuChoice = input.nextLine();
        actionOnMenuChoice(menuChoice);
        }
        else
        {ExitApplication();}}
    public void DisplayMenu() //Displaying the menu
    {System.out.println
        ("PLEASE SELECT OPTION FROM THR FOLLOWING LIST\n"
        + "\n1) Capture new task"
        + "\n2) Search new task"
        + "\n3) Update a task detail"
        + "\n4) Delete a task added"
        + "\n5) Print Out Report"
        + "\n6) Exit Application");
    }

    public void actionOnMenuChoice (String choice){       
       switch (choice) {
            case "1":   CaptureTask();
                        break;
            case "2":   SearchForTask();
                        break;
            case "3":   UpdateTask();
                        break;
            case "4":   DeleteTask();
                        break;
            case "5":   PrintReport();
                        break;
            case "6":   ExitApplication();
                        break;   
            default :
                        JOptionPane.showMessageDialog(null,"404 ERROR!!\n");
                        programIn("1");
                        break;
        }
    }    
    public void CaptureTask() 
    {
        //varibles
        String K,description;
        System.out.println("CAPTURE A NEW TASK\n"
        + "******************************************************");
       
        System.out.print("Enter TASK ID: ");
        K = input.nextLine();
        System.out.print("Enter TASK Name: ");
        Description = input.nextLine();
        System.out.println();
        selectTaskStatus();       
        selectWarranty();
        
        System.out.print("Enter TASK DURATION (HOURS):    ");
        Pricetag= input.nextDouble();
        System.out.print("Enter TASK NUMBER:  ");
        Task_levels = input.nextInt();
        input.nextLine();
        System.out.print("Enter DEVELOPER DETAILS:  ");
        Developer = input.nextLine();

        Task.SaveTask(K,Description,category,Warranty,Developer, Pricetag,Task_levels);
        NumOfTasks++;
        JOptionPane.showMessageDialog(null,"**************************************\nTASK DETAILS SAVED SUCCESSFULLY!!!\n******************************************");
        prompt();

    }

    public void selectWarranty() {
        System.out.println("\nSELECT THE TASK DURATION YOU WANT: "
         + "\n(1)       1 YEAR \n(ANY KEY)  +2 YEARS.");
        String selection = input.next();
        if (selection.equalsIgnoreCase("1")) {
            warranty = "1 YEAR";
        }else {
            warranty = "+2 YEARS";}
    }
    public String changeWarranty() {
        System.out.println("\nSELECT THE TASK DURATION YOU WANT: "
         + "\n(1)1 YEAR \n(ANY KEY)+2 YEARS.");
        String selection = input.next();
        if (selection.equalsIgnoreCase("1")) {
            return "1 YEAR";
        }else {
            return "2 YEARS";     
        }
    }    public void selectTaskStatus(){
        System.out.println("SELECT TASK STATUS: ");
         System.out.println("1)TO DO"
                       + "\n2)DONE"
                        + "\n3)DOING");
        System.out.println();
         String choiceOFselection = input.nextLine();
         //making use of switch statements
        switch (choiceOFselection) {
            case "1":
                category = "TO DO";
                break;
            case "2":
                category = "DONE";
                break;
            case "3":
                category = "DOING";
                break;   
            //should user insert an invalid option   
            default:
            JOptionPane.showMessageDialog(null,"\n404 Error!!!!!!!!!!!!!!!!!!! INVALID SELECTION");
            selectTASKSTATUS();
            break;
        }   
    }
    public void SearchForTask () {
        System.out.print("Enter TASK ID to search: ");
        String codeToSearch = input.nextLine();
        System.out.println("*****************************************\n");
        int id = Task.getTaskID(codeToSearch);
        System.out.println("TASK SEARCH RESULTS\n");
        System.out.println("*******************************\n");             
                if( id== Integer.MAX_VALUE)
                {
                   JOptionPane.showMessageDialog(null,"The task cannot be located. ");
                    prompt();
                }
                else{ System.out.println(
                     "PRODUCT Task: "           + Task.getCode(id)
                    + "\nTASK Name: "           + Task.getName(id)
                    + "\nTASK Status: "         + Task.getCategory(id)
                    + "\nTASK DURATION: "       + Task.getWarranty(id)
                    + "\nTASK VALUE:   "        + Task.getPrice(id)
                    + "\nDEVELOPER NAME: "      + Task.getdeveloper(id)
                    + "\nTASK LEVEL: "          + Task.getTask_levels(id));
                    }prompt();
    }
    public void UpdateTask()
    {
        System.out.print("ENTER TASK ID TO UPDATE: ");
        String codeToSearch = input.nextLine();
        double newPrice ;
        int newStockLevel; 
        int id = Task.getTaskID(codeToSearch);
        String yesOrNo,yesOrNo1,yesOrNo2;
        if(id == Integer.MAX_VALUE)
        {
           JOptionPane.showMessageDialog(null,"TASK ID NOT FOUND!!!!!!!!!!!!!!!!!!!!!!!!!");
            prompt();
        }
        else
        { // updating a task
            System.out.print("UPDATE TASK DURATION?(y/n):");
            yesOrNo = input.next();
      
            if(yesOrNo.equals("y"))
            {
                System.out.println("ENTER NEW DURATION: " + Task.getName(id) + "\n");
               Task.setWarranty(changeWarranty(),id);
            }
            System.out.println("UPDATE TASK PRICE?(y/n):");
            yesOrNo1 = input.next();
            
            if(yesOrNo1.equals("y"))
            {
                System.out.print("ENTER PRICE FOR:" + Task.getName(id) +" : ");
                newPrice = input.nextInt();
              Task.setPrice(newPrice,id);
            }

            System.out.println("UPDATE TASK LEVEL?(y/n):");
            yesOrNo2 = input.next();if(yesOrNo2.equals("y"))
            {
                System.out.println("ENTER NEW TASK LEVEL" + Task.getName(id) + " ");
                newTaskLevel = input.nextInt();
               Task.setTask_levels(newTaskLevel,id);
            }
            JOptionPane.showMessageDialog(null,"**************************************\nTASK DETAILS UPDATED SUCCESSFULLY\n****************************************");
            input.nextLine();
            prompt();
        }
    } // deleting a task
    public void DeleteTask () {
        System.out.print("ENTER TASK ID FOR DELETION: ");
        String ccode = input.nextLine();
        int id  =Task.getTaskID(ccode);

        if(NumOfTasks ==1)
        {NumOfTasks = 0;}
        if(id != Integer.MAX_VALUE)
        {for(int k=id; k<NumOfTasks-1; k++)
            {
               TaskID[k] = TaskID[k+1];
               Name[k] = Name[k+1];
               Category[k] = Category1[k+1];
               Duration[k] = Duration[k+1];
               Developer[k] = Developer[k+1];
               Pricetag[k] = Pricetag[k+1];
               Task_levels[k] = Task_levels1[k+1];}
            if(NumOfTasks >0)
            NumOfTasks--;}
        else{
       JOptionPane.showMessageDialog(null,"404 ERORR!!!!!!!!!! \nTASK CAN'T BE LOCATED!!!!!!!!!!!!!!!");
        prompt();}
       JOptionPane.showMessageDialog(null,"TASK DELETED successfully!!!");
        prompt();}
    @SuppressWarnings("empty-statement")
        public void PrintReport () {
        double totalAmount  =0.0;
        System.out.println("TASK REPORT");
        System.out.println("*********************************************************");       
        if(NumOfTasks == 0 )
        {System.out.println("NO TASK IN AVAILABLE");}
         for(int k=0; k<NumOfTasks;k++)
        {
            System.out.println();
            
             JOptionPane.showMessageDialog(null,"***********************************************\n" +       
              "TASK REPORT: " + (k+1) + "\n*************************************************" +
              "\nTASK ID:                                  " + Task.TaskId[k] +"\n"
            + "TASK NAME:                           "+ Task.Name[k] + "\n"
            + "TASK STATUS (1-3):              "+ Task.Category[k] + "\n"
            + "TASK DURATION:                   "+ Task.Duration[k] + "\n" 
            + "TASK PRICE:                           R" + Task.Pricetag[k] + "\n"
            + "TASK LEVEL:                          " + Task.Task_Levels1[k] + "\n"
            + "DEVELOPER NAME :              " + Task.Developer[k] + "\n"
            + "****************************************************");
            ;
        }
        for(int l=0; l<NumOfTasks; l++)
        {TotalAmount += Task.Pricetag[l];
        }
   JOptionPane.showMessageDialog(null,"*****************************************\nTOTAL TASK COUNT : " + NumOfTasks + "\n"
                                    + "TOTAL TASK VALUE:  " + totalAmount + "\n**********************************************");
    
        if(NumOfTasks== 0 )
        { JOptionPane.showMessageDialog(null,"********************************\nAVERAGE TASK VALUE: " + 0 + "\n********************************************");
        }else  JOptionPane.showMessageDialog(null, "AVERAGE TASK VALUE: " 
        + (totalAmount/NumOfTasks));    
    }
    public void ExitApplication() {
    System.exit(0);
    }
}
